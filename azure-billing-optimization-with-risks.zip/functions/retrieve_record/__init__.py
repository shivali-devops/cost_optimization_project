import gzip, json
from azure.cosmos import CosmosClient
from azure.storage.blob import BlobServiceClient

COSMOS_URI = "<COSMOS_URI>"
COSMOS_KEY = "<COSMOS_KEY>"
DB_NAME = "BillingDB"
CONTAINER_NAME = "Records"

BLOB_CONN_STR = "<BLOB_CONN_STR>"
ARCHIVE_CONTAINER = "billing-archive"

cosmos = CosmosClient(COSMOS_URI, COSMOS_KEY)
container = cosmos.get_database_client(DB_NAME).get_container_client(CONTAINER_NAME)
blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
archive_container = blob_service.get_container_client(ARCHIVE_CONTAINER)

def main(req):
    record_id = req.params.get('id')
    if not record_id:
        return {"status": 400, "body": "Missing id"}

    try:
        record = container.read_item(record_id, partition_key=record_id)
        return {"status": 200, "body": record}
    except:
        blob_client = archive_container.get_blob_client(f"{record_id}.json.gz")
        if blob_client.exists():
            data = gzip.decompress(blob_client.download_blob().readall())
            return {"status": 200, "body": json.loads(data)}
        return {"status": 404, "body": "Record not found"}
