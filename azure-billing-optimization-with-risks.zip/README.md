# Azure Billing Optimization

## Overview
This solution reduces Azure Cosmos DB cost by archiving old billing records (>90 days) into Azure Blob Storage while keeping them accessible via the same API.

## Architecture
- Active Data: Cosmos DB (last 90 days)
- Archive Data: Azure Blob Storage (older records)
- Functions: 
  - Archive job (timer)
  - Retrieval fallback

## Deployment
1. Deploy infrastructure:
   ```bash
   terraform -chdir=infra init
   terraform -chdir=infra apply -auto-approve
   ```
2. Deploy Azure Functions:
   ```bash
   func azure functionapp publish billing-functions
   ```

## Cost Optimization
- Cosmos DB keeps minimal active data.
- Blob Storage cool/archive tiers reduce costs.
- Lifecycle policy moves data to cheaper storage after 180 days.
